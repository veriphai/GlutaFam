import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:lottie/lottie.dart';
import 'dart:io';
import 'ai_tutor_helpers.dart';

class FeedbackCards {
  static Widget gapCard(
    Map<String, dynamic> gap,
    int turnIndex,
    Set<String> resolvedGaps,
    Function(Map<String, dynamic>) onResolveGap,
    Function(Map<String, dynamic>) onDismissGap, {
    Map<String, List<Map<String, dynamic>>>? gapConversations,
    Map<String, bool>? expandedGaps,
    Map<String, TextEditingController>? gapTextControllers,
    Map<String, bool>? gapLoadingStates,
    Function(String, String)? onSendGapMessage,
    Function(String, File)? onSendGapAudio,
    Function(String)? onToggleGapExpansion,
    String? conceptId,
    String? studentName,
    int? checkpointNo,
    String? conceptConversationsKey,
    int? remainingTime,
    String? language,
    String? voice,
  }) {
    final String text = gap['text'] ?? '';
    final int severity = gap['severity'] ?? 0;
    final double confidence = (gap['confidence'] ?? 0.0) is num
        ? (gap['confidence'] as num).toDouble()
        : double.tryParse('${gap['confidence']}') ?? 0.0;

    // Check if gap is resolved
    final bool isResolved = AITutorHelpers.isGapResolved(gap, resolvedGaps);

    // Color coding based on resolved status and severity
    Color cardColor, borderColor, iconBgColor, titleColor;
    IconData iconData;
    String statusText;

    if (isResolved) {
      // Green theme for resolved gaps
      cardColor = const Color(0xFFF0FDF4); // Light green
      borderColor = const Color(0xFF84CC16); // Green border
      iconBgColor = const Color(0xFF16A34A); // Green background for icon
      titleColor = const Color(0xFF15803D); // Dark green for text
      iconData = Icons.check_circle;
      statusText = 'Gap resolved';
    } else if (severity == 1) {
      // Yellow theme for severity 1
      cardColor = const Color(0xFFFFFBEB); // Light yellow
      borderColor = const Color(0xFFFDE047); // Yellow border
      iconBgColor = const Color(0xFFEAB308); // Yellow background for icon
      titleColor = const Color(0xFFCA8A04); // Darker yellow for text
      iconData = Icons.warning;
      statusText = 'Gap identified';
    } else {
      // Red theme for severity 2+
      cardColor = const Color(0xFFFDF2F8); // Light pink
      borderColor = const Color(0xFFFDA4AF); // Pink border
      iconBgColor = const Color(0xFFDC2626); // Red background for icon
      titleColor = const Color(0xFFDC2626); // Red for text
      iconData = Icons.warning;
      statusText = 'Gap identified';
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: cardColor,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: borderColor),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with warning icon and "Gap identified"
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: iconBgColor,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Icon(
                    iconData,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  statusText,
                  style: GoogleFonts.raleway(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: titleColor,
                  ),
                ),
                const Spacer(),
                // Severity indicator
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: iconBgColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    'Level $severity',
                    style: GoogleFonts.raleway(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: titleColor,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Gap description
            Text(
              text,
              style: GoogleFonts.raleway(
                fontSize: 14,
                color: const Color(0xFF374151),
                height: 1.4,
              ),
            ),

            // Confidence indicator
            if (confidence > 0) ...[
              const SizedBox(height: 8),
              Text(
                'Confidence: ${(confidence * 100).toStringAsFixed(0)}%',
                style: GoogleFonts.raleway(
                  fontSize: 12,
                  color: const Color(0xFF6B7280),
                ),
              ),
            ],

            const SizedBox(height: 16),

            // Check if gap conversation is expanded
            ...() {
              if (expandedGaps == null || gapConversations == null) {
                return <Widget>[];
              }

              final String gapId = AITutorHelpers.getGapId(gap);
              final bool isExpanded = expandedGaps[gapId] ?? false;
              final List<Map<String, dynamic>> conversations =
                  gapConversations[gapId] ?? [];

              if (!isExpanded) {
                return <Widget>[];
              }

              return [
                // Conversation area
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: borderColor.withOpacity(0.3)),
                  ),
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Conversation header
                      Row(
                        children: [
                          Icon(
                            Icons.chat_bubble_outline,
                            size: 16,
                            color: titleColor,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            'Gap Resolution Chat',
                            style: GoogleFonts.raleway(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: titleColor,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),

                      // Conversation messages
                      if (conversations.isNotEmpty) ...[
                        Container(
                          constraints: const BoxConstraints(maxHeight: 300),
                          child: ListView.builder(
                            shrinkWrap: true,
                            itemCount: conversations.length,
                            itemBuilder: (context, index) {
                              final conversation = conversations[index];
                              final role = conversation['role'];

                              if (role == 'assistant') {
                                return _buildGapAssistantBubble(
                                  conversation['text'] ?? '',
                                  conversation,
                                );
                              } else if (role == 'user') {
                                return _buildGapUserBubble(
                                  conversation['text'] ?? '',
                                  conversation,
                                );
                              }
                              return const SizedBox.shrink();
                            },
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],

                      // Input area
                      if (gapTextControllers != null &&
                          onSendGapMessage != null) ...[
                        Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: gapTextControllers[gapId],
                                decoration: InputDecoration(
                                  hintText: 'Ask about this gap...',
                                  hintStyle: GoogleFonts.raleway(
                                    fontSize: 14,
                                    color: const Color(0xFF9CA3AF),
                                  ),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20),
                                    borderSide: BorderSide(
                                      color: borderColor,
                                    ),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20),
                                    borderSide: BorderSide(
                                      color: borderColor,
                                    ),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(20),
                                    borderSide: BorderSide(
                                      color: iconBgColor,
                                      width: 2,
                                    ),
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 12,
                                  ),
                                ),
                                style: GoogleFonts.raleway(fontSize: 14),
                                maxLines: null,
                                textCapitalization:
                                    TextCapitalization.sentences,
                              ),
                            ),
                            const SizedBox(width: 8),
                            // Send button
                            Container(
                              decoration: BoxDecoration(
                                color: iconBgColor,
                                shape: BoxShape.circle,
                              ),
                              child: IconButton(
                                onPressed: (gapLoadingStates?[gapId] ?? false)
                                    ? null
                                    : () {
                                        final text = gapTextControllers[gapId]
                                                ?.text
                                                .trim() ??
                                            '';
                                        if (text.isNotEmpty) {
                                          onSendGapMessage(gapId, text);
                                          gapTextControllers[gapId]?.clear();
                                        }
                                      },
                                icon: (gapLoadingStates?[gapId] ?? false)
                                    ? SizedBox(
                                        width: 16,
                                        height: 16,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                            Colors.white,
                                          ),
                                        ),
                                      )
                                    : const Icon(
                                        Icons.send,
                                        color: Colors.white,
                                        size: 18,
                                      ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 16),
              ];
            }(),

            // Action buttons - different for resolved gaps
            if (!isResolved)
              Row(
                children: [
                  // Resolve now button - now toggles conversation
                  Expanded(
                    child: ElevatedButton(
                      onPressed: null, // Disabled button
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            const Color(0xFF9CA3AF), // Grayed out background
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        elevation: 0,
                        disabledBackgroundColor: const Color(0xFF9CA3AF),
                        disabledForegroundColor: Colors.white,
                      ),
                      child: Text(
                        'Resolve Now - Coming soon',
                        style: GoogleFonts.raleway(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),

                  // Later button
                  // Expanded(
                  //   child: OutlinedButton(
                  //     onPressed: () => onDismissGap(gap),
                  //     style: OutlinedButton.styleFrom(
                  //       foregroundColor: const Color(0xFF6B7280),
                  //       side: const BorderSide(color: Color(0xFFD1D5DB)),
                  //       shape: RoundedRectangleBorder(
                  //         borderRadius: BorderRadius.circular(8),
                  //       ),
                  //       padding: const EdgeInsets.symmetric(vertical: 12),
                  //     ),
                  //     child: Text(
                  //       'Later',
                  //       style: GoogleFonts.raleway(
                  //         fontSize: 14,
                  //         fontWeight: FontWeight.w600,
                  //       ),
                  //     ),
                  //   ),
                  // ),
                ],
              )
            else
              // Resolved gap status message
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: const Color(0xFF16A34A).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.check_circle,
                          color: const Color(0xFF16A34A),
                          size: 16,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'This gap has been resolved',
                          style: GoogleFonts.raleway(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: const Color(0xFF16A34A),
                          ),
                        ),
                      ],
                    ),
                    if (confidence > 0) ...[
                      const SizedBox(height: 8),
                      Text(
                        'Resolution confidence: ${(confidence * 100).toStringAsFixed(0)}%',
                        style: GoogleFonts.raleway(
                          fontSize: 12,
                          color: const Color(0xFF15803D),
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  static Widget turnFeedbackCard(
    Map<String, dynamic> fb,
    Function(Map<String, dynamic>) onResolveFeedback,
    Function(Map<String, dynamic>) onDismissFeedback,
  ) {
    final List missingPts = (fb['missingPoints'] ?? []) as List;

    // Only show feedback if there are gaps (missing points)
    if (missingPts.isEmpty) {
      return const SizedBox.shrink();
    }

    // Combine all missing points into a single gap description
    final String gapDescription = missingPts.take(2).join(' ');

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFFDF2F8), // Light pink background
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFFDA4AF)), // Pink border
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with warning icon and "Gap identified"
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFDC2626), // Red background for icon
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Icon(
                    Icons.warning,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Gap identified',
                  style: GoogleFonts.raleway(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFFDC2626),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Gap description
            Text(
              gapDescription,
              style: GoogleFonts.raleway(
                fontSize: 14,
                color: const Color(0xFF374151),
                height: 1.4,
              ),
            ),
            const SizedBox(height: 16),

            // Action buttons
            Row(
              children: [
                // Resolve now button
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => onResolveFeedback(fb),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1D4ED8),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      elevation: 0,
                    ),
                    child: Text(
                      'Resolve now',
                      style: GoogleFonts.raleway(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),

                // Later button
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => onDismissFeedback(fb),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF6B7280),
                      side: const BorderSide(color: Color(0xFFD1D5DB)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text(
                      'Later',
                      style: GoogleFonts.raleway(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  static Widget cumulativeFeedbackCard(
    Map<String, dynamic> cp,
    Function(Map<String, dynamic>) onResolveFeedback,
    Function(Map<String, dynamic>) onDismissFeedback,
  ) {
    final List unresolved = (cp['unresolvedGaps'] ?? []) as List;

    // Only show feedback if there are unresolved gaps
    if (unresolved.isEmpty) {
      return const SizedBox.shrink();
    }

    // Combine unresolved gaps into a single description
    final String gapDescription = unresolved
        .take(2)
        .map((g) => '${g['summary'] ?? g['text'] ?? g}')
        .join(' ');

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFFFDF2F8), // Light pink background
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFFDA4AF)), // Pink border
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header with warning icon and "Gap identified"
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: const Color(0xFFDC2626), // Red background for icon
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: const Icon(
                    Icons.warning,
                    color: Colors.white,
                    size: 16,
                  ),
                ),
                const SizedBox(width: 8),
                Text(
                  'Gap identified',
                  style: GoogleFonts.raleway(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: const Color(0xFFDC2626),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Gap description
            Text(
              gapDescription,
              style: GoogleFonts.raleway(
                fontSize: 14,
                color: const Color(0xFF374151),
                height: 1.4,
              ),
            ),
            const SizedBox(height: 16),

            // Action buttons
            Row(
              children: [
                // Resolve now button
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => onResolveFeedback(cp),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF1D4ED8),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      elevation: 0,
                    ),
                    child: Text(
                      'Resolve now',
                      style: GoogleFonts.raleway(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),

                // Later button
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => onDismissFeedback(cp),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFF6B7280),
                      side: const BorderSide(color: Color(0xFFD1D5DB)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    child: Text(
                      'Later',
                      style: GoogleFonts.raleway(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Helper method to build assistant bubble for gap conversations
  static Widget _buildGapAssistantBubble(
    String text,
    Map<String, dynamic> conversation,
  ) {
    final isLoading = conversation['isLoading'] == true;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Small avatar
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: const Color(0xFF1D4ED8),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.smart_toy,
              color: Colors.white,
              size: 14,
            ),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFFF8FAFC),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFE2E8F0)),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: isLoading
                  ? SizedBox(
                      height: 16,
                      width: 16,
                      child: Lottie.asset(
                        "lib/assets/animations/3-dots.json",
                        fit: BoxFit.cover,
                      ),
                    )
                  : Text(
                      text,
                      style: GoogleFonts.raleway(
                        fontSize: 13,
                        color: const Color(0xFF374151),
                        height: 1.3,
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }

  // Helper method to build user bubble for gap conversations
  static Widget _buildGapUserBubble(
    String text,
    Map<String, dynamic> conversation,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Flexible(
            child: Container(
              decoration: BoxDecoration(
                color: const Color(0xFF1D4ED8).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border:
                    Border.all(color: const Color(0xFF1D4ED8).withOpacity(0.3)),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Text(
                text,
                style: GoogleFonts.raleway(
                  fontSize: 13,
                  color: const Color(0xFF1E40AF),
                  height: 1.3,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          // Small user icon
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: const Color(0xFF1D4ED8),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.person,
              color: Colors.white,
              size: 14,
            ),
          ),
        ],
      ),
    );
  }
}
